from TOPSIS-kritika-101983031 import sum_of_squares
from TOPSIS-kritika-101983031 import normalized
from TOPSIS-kritika-101983031 import best
from TOPSIS-kritika-101983031 import worst
from TOPSIS-kritika-101983031 import euclidean_distances